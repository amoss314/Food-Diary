package umsl.edu.foodfinal;  
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FoodDiary {


public static void main(String[] args) {
BufferedWriter bw = null;
FileWriter fw = null;
//try {
//	FileOutputStream FileName = new FileOutputStream( "MyFoodDiary.csv");
//} catch (FileNotFoundException e1) {
//	// TODO Auto-generated catch block
//	e1.printStackTrace();
//}
System.out.println("Welcome to your food diary");
System.out.println("What is the date today? (ex. 04)");
Scanner p = new Scanner(System.in);
int l = p.nextInt();
System.out.println("What is the name of your Food?");
Scanner x = new Scanner(System.in);
String f = x.nextLine();
System.out.println("Was this breakfast, lunch, dinner, or a snack");
Scanner y = new Scanner(System.in);
String t = y.nextLine();
System.out.println("How many calories?");
Scanner r = new Scanner(System.in);
int w = r.nextInt();





try {

  File file = new File("MyFoodDiary.csv");

  // if file doesnt exists, then create it
  if (!file.exists()) {
      file.createNewFile();
  	fw = new FileWriter("MyFoodDiary.csv", true);
  	bw = new BufferedWriter(fw);
  	bw.write("Date, Food Name, Food Time, Calories, ");
  	bw.close();
  }

   //true = append file
  fw = new FileWriter("MyFoodDiary.csv", true);
  bw = new BufferedWriter(fw);

  bw.write("\n");
  //NEW CODE
  bw.write(Integer.toString(l));
  //NEW CODE
  bw.write(",");
  bw.write(f);
  bw.write(",");
  bw.write(t);
  bw.write(",");
  bw.write(Integer.toString(w));
  System.out.println("Done");

} catch (IOException e) {

  e.printStackTrace();

} finally {

  try {

      if (bw != null)
          bw.close();

      if (fw != null)
          fw.close();

  } catch (IOException ex) {

      ex.printStackTrace();

  }
	

}}}
